﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;


namespace LibraryManagementSystem.Models
{
    public class Books
    {
        public int BookId { get; set; }
        [Required(ErrorMessage = "This field is required.")]
        public string Title { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        public string Author { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        [RegularExpression(@"^[0-9]+$",
                            ErrorMessage = "Enter valid ISBN Number .")]
        public string ISBN { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        public string Publisher { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        [RegularExpression(@"^[0-9]{4}",
                            ErrorMessage = "Enter valid Year .")]
        public string Year { get; set; }
    }
}