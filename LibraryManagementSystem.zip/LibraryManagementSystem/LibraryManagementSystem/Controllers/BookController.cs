﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LibraryManagementSystem.Models;
using System.Data.Sql;
namespace LibraryManagementSystem.Controllers
{
    public class BookController : Controller
    {
        BookdbDataContext con = new BookdbDataContext();

        // GET: Book
        public ActionResult Index(string search)
        {
            dynamic data = null;
            //if(SearchBy == "Title")
            //{                
            //    return View(con.sp_getbooks().Where(x=>x.Title.ToLower().StartsWith(search.ToLower())).ToList());
            //}
            //else if(SearchBy=="Author")
            //{
            //    return View(con.sp_getbooks().Where(x => x.Author.ToLower().StartsWith(search.ToLower())).ToList());
            //}
            if (search != null)
            {
                data = con.sp_getbooks().Where(x => x.Title.ToLower().StartsWith(search.ToLower())).ToList();
                if (data.Count == 0)
                {
                    data = con.sp_getbooks().Where(x => x.Author.ToLower().StartsWith(search.ToLower())).ToList();
                    return View(data);
                }
                else
                {
                    return View(data);
                }
            }
            else
            {
                return View(con.sp_getbooks().ToList());
            }

        }

        // GET: Book/Details/5
        public ActionResult Details(int id)
        {
            var getbookdetails = con.sp_getbooks().Single(x => x.BookId == id);
            return View(getbookdetails);
        }

        // GET: Book/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Book/Create
        [HttpPost]
        public ActionResult Create(FormCollection frm)
        {
            int? rval = 0;
            try
            {
                // TODO: Add insert logic here
                rval = con.sp_addbooks(frm["Title"], frm["Author"], frm["ISBN"], frm["Publisher"], frm["year"], ref rval);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Book/Edit/5
        public ActionResult Edit(int id)
        {
            var getbookdetails = con.sp_getbooks().Single(x => x.BookId == id);
            return View(getbookdetails);
        }

        // POST: Book/Edit/5
        [HttpPost]
        public ActionResult Edit(FormCollection frm)
        {
            int book_id = Convert.ToInt32(Request.Form["BookId"]);
            int? rval = 0;
            try
            {
                // TODO: Add update logic here
                rval = con.sp_updatebookdetails(frm["Title"], frm["Author"], frm["ISBN"], frm["Publisher"], frm["year"], book_id, ref rval);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Book/Delete/5
        public ActionResult Delete(int id)
        {
            var getbookdetails = con.sp_getbooks().Single(x => x.BookId == id);
            return View(getbookdetails);
        }

        // POST: Book/Delete/5
        [HttpPost]
        public ActionResult Delete(FormCollection collection)
        {
            int book_id = Convert.ToInt32(Request.Form["BookId"]);
            int? rval = 0;
            try
            {
                // TODO: Add delete logic here
                rval = con.sp_deletebook(book_id, ref rval);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }


    }
}
